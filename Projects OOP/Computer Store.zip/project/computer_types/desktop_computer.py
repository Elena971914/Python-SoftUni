from project.computer_types.computer import Computer


class DesktopComputer(Computer):
    MAX_RAM = 128
    PROCESSORS = {"AMD Ryzen 7 5700G": 500,
                  "Intel Core i5-12600K": 600,
                  "Apple M1 Max": 1800}

    def __init__(self, manufacturer, model):
        super().__init__(manufacturer, model)

    def configure_computer(self, processor, ram):

        if processor not in DesktopComputer.PROCESSORS:
            raise ValueError(f"{processor} is not compatible with desktop "
                             f"computer {self.manufacturer} {self.model}!")

        if ram not in [2 ** i for i in range(1, 8)]:
            raise ValueError(f"{ram}GB RAM is not compatible with "
                             f"desktop computer {self.manufacturer} {self.model}!")

        def power(ram):
            multiply = 0
            while not ram == 1:
                if ram % 2 == 0:
                    multiply += 1
                    ram = ram / 2
                else:
                    break
            return multiply

        self.price += power(ram) * 100 + DesktopComputer.PROCESSORS[processor]
        self.processor = processor
        self.ram = ram

        return f"Created {self.manufacturer} {self.model} with " \
               f"{self.processor} and {self.ram}GB RAM for {self.price}$."
