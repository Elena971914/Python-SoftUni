from project.computer_types.computer import Computer


class Laptop(Computer):
    LAPTOPS = {'AMD Ryzen 9 5950X': 900,
               'Intel Core i9-11900H': 1050,
               'Apple M1 Pro': 1200}
    MAX_RAM = 64

    def __init__(self, manufacturer, model):
        super().__init__(manufacturer, model)

    def configure_computer(self, processor, ram):

        if processor not in Laptop.LAPTOPS:
            raise ValueError(f"{processor} is not compatible with laptop "
                             f"{self.manufacturer} {self.model}!")

        if ram not in [2 ** i for i in range(1, 7)]:
            raise ValueError(f"{ram}GB RAM is not compatible with laptop "
                             f"{self.manufacturer} {self.model}!")

        def power(ram):
            multiply = 0
            while not ram == 1:
                if ram % 2 == 0:
                    multiply += 1
                    ram = ram / 2
                else:
                    break
            return multiply

        self.processor = processor
        self.ram = ram
        self.price += power(ram) * 100 + Laptop.LAPTOPS[self.processor]

        return f"Created {self.manufacturer} {self.model} with " \
               f"{self.processor} and {self.ram}GB RAM for {self.price}$."
