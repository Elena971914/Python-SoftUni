from project.computer_types.desktop_computer import DesktopComputer
from project.computer_types.laptop import Laptop


class ComputerStoreApp:
    def __init__(self):
        self.warehouse = []
        self.profits = 0

    def build_computer(self, type_computer, manufacturer, model, processor, ram):
        if not type_computer == "Desktop Computer" and not type_computer == "Laptop":
            raise ValueError(f"{type_computer} is not a valid type computer!")

        elif type_computer == "Laptop":
            new = Laptop(manufacturer, model)
        elif type_computer == "Desktop Computer":
            new = DesktopComputer(manufacturer, model)

        conf = new.configure_computer(processor, ram)
        self.warehouse.append(new)
        return conf

    def sell_computer(self, client_budget, wanted_processor, wanted_ram):
        for computer in self.warehouse:
            if client_budget >= computer.price and \
                    wanted_processor == computer.processor \
                    and wanted_ram <= computer.ram:
                self.profits += client_budget - computer.price
                self.warehouse.remove(computer)

                return f"{computer} sold for {client_budget}$."
        else:
            raise Exception("Sorry, we don't have a computer for you.")
