class Controller:
    def __init__(self):
        self.players = []
        self.supplies = []

    def add_player(self, *players):
        added_players_names = []

        for player in players:
            if player not in self.players:
                self.players.append(player)
                added_players_names.append(player.name)

        return f"Successfully added: {', '.join(added_players_names)}"

    def add_supply(self, *supplies):

        for supply in supplies:
            self.supplies.append(supply)

    def sustain(self, player_name, sustenance_type):
        player = None
        for play in self.players:
            if play.name == player_name:
                player = play

        if not player:
            return

        elif sustenance_type not in ["Food", "Drink"]:
            return

        if player.stamina == 100:
            return f"{player_name} have enough stamina."

        try:
            supply = [s for s in self.supplies if s.__class__.__name__ == sustenance_type].pop()
        except IndexError:
            if sustenance_type == "Drink":
                raise Exception(f"There are no drink supplies left!")
            elif sustenance_type == "Food":
                raise Exception("There are no food supplies left!")

        if player.stamina + supply.energy > 100:
            player.stamina = 100
        else:
            player.stamina += supply.energy

        self.supplies.reverse()
        self.supplies.remove(supply)
        self.supplies.reverse()

        return f"{player_name} sustained successfully with {supply.name}."

    def duel(self, first_player_name, second_player_name):
        player_one = next(filter(lambda p: p.name == first_player_name, self.players))
        player_two = next(filter(lambda p: p.name == second_player_name, self.players))

        if player_one.stamina == 0:
            if player_two.stamina == 0:
                return f"Player {first_player_name} does not have enough stamina.\n" \
                       f"Player {second_player_name} does not have enough stamina."
            return f"Player {first_player_name} does not have enough stamina."

        elif player_two.stamina == 0:
            return f"Player {second_player_name} does not have enough stamina."

        first_to_attack = player_two if player_one.stamina > player_two.stamina else player_one
        second_to_attack = player_one if first_to_attack == player_two else player_two

        if second_to_attack.stamina - first_to_attack.stamina / 2 <= 0:
            second_to_attack.stamina = 0
            return f"Winner: {first_to_attack.name}"

        second_to_attack.stamina -= first_to_attack.stamina / 2

        if first_to_attack.stamina - second_to_attack.stamina / 2 <= 0:
            first_to_attack.stamina = 0
            return f"Winner: {second_to_attack.name}"

        first_to_attack.stamina -= second_to_attack.stamina / 2

        return f"Winner: {player_one.name if player_one.stamina > player_two.stamina else player_two.name}"

    def next_day(self):
        for player in self.players:
            if player.stamina - player.age * 2 < 0:
                player.stamina = 0
            else:
                player.stamina -= player.age * 2

            self.sustain(player.name, "Food")
            self.sustain(player.name, "Drink")

    def __str__(self):
        result = []
        for player in self.players:
            result.append(str(player))
        for supply in self.supplies:
            result.append(supply.details())

        return '\n'.join(result)




