class Zoo:
    def __init__(self, name, budget, animal_capacity, workers_capacity):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.animals = []
        self.workers = []

    def add_animal(self, animal, price):
        if price <= self.__budget and self.__animal_capacity:
            self.animals.append(animal)
            self.__animal_capacity -= 1
            self.__budget -= price
            return f"{animal.name} the {animal.__class__.__name__} added to the zoo"
        elif price > self.__budget and self.__animal_capacity:
            return "Not enough budget"
        elif not self.__animal_capacity:
            return "Not enough space for animal"

    def hire_worker(self, worker):
        if len(self.workers) < self.__workers_capacity:
            self.workers.append(worker)
            return f"{worker.name} the {worker.__class__.__name__} hired successfully"
        else:
            return "Not enough space for worker"

    def fire_worker(self, worker_name):
        #try:
        #   worker = next(filter(lambda w: w.name == worker_name, self.workers)
        #except StopIteration:
        #   return f"There is no {worker_name} in the zoo"
        #self.workers.remove(worker)
        #return f"{worker_name} fired successfully"

        for worker in self.workers:
            if worker.name == worker_name:
                self.workers.remove(worker)
                self.__workers_capacity += 1
                return f"{worker_name} fired successfully"
        else:
            return f"There is no {worker_name} in the zoo"

    def pay_workers(self):
        salaries = 0
        for worker in self.workers:
            salaries += worker.salary

        if salaries > self.__budget:
            return "You have no budget to pay your workers. They are unhappy"

        self.__budget -= salaries
        return f"You payed your workers. They are happy. Budget left: {self.__budget}"

    def tend_animals(self):
        tending_price = 0
        for animal in self.animals:
            tending_price += animal.money_for_care

        if tending_price > self.__budget:
            return "You have no budget to tend the animals. They are unhappy."

        self.__budget -= tending_price
        return f"You tended all the animals. They are happy. Budget left: {self.__budget}"

    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        result = [f"You have {len(self.animals)} animals"]

        lions = list(filter(lambda l: l.__class__.__name__ == "Lion", self.animals))
        cheetahs = list(filter(lambda c: c.__class__.__name__ == "Cheetah", self.animals))
        tigers = list(filter(lambda t: t.__class__.__name__ == "Tiger", self.animals))

        if lions:
            result.append(f"----- {len(lions)} Lions:")
            for lion in lions:
                result.append(f"{lion}")
        if tigers:
            result.append(f"----- {len(tigers)} Tigers:")
            for tiger in tigers:
                result.append(f"{tiger}")
        if cheetahs:
            result.append(f"----- {len(cheetahs)} Cheetahs:")
            for cheetah in cheetahs:
                result.append(f"{cheetah}")

        return "\n".join(result)

    def workers_status(self):
        res = []

        res.append(f"You have {len(self.workers)} workers")

        keepers = list(filter(lambda x: x.__class__.__name__ == "Keeper", self.workers))
        vets = list(filter(lambda x: x.__class__.__name__ == "Vet", self.workers))
        caretakers = list(filter(lambda x: x.__class__.__name__ == "Caretaker", self.workers))

        if keepers:
            res.append(f"----- {len(keepers)} Keepers:")
            for keeper in keepers:
                res.append(f"{keeper}")
        if caretakers:
            res.append(f"----- {len(caretakers)} Caretakers:")
            for caretaker in caretakers:
                res.append(f"{caretaker}")
        if vets:
            res.append(f"----- {len(vets)} Vets:")
            for vet in vets:
                res.append(f"{vet}")

        return "\n".join(res)



