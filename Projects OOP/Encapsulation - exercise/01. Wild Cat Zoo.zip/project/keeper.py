from project.worker import Worker


class Keeper(Worker):
    pass